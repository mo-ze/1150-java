


public class q23rdjulycode__recursion {
    public static void main(String[] args) {
    System.out.println(method(4));

    }

    public static int method(int x) {
    if (x==0){

    }

    System.out.println(x);
    return x+method(--x);
    }
  

//    ab
//    return aa,ab,bb,ba
//
    /*
    public static void compute(String in){
       char[] ar= in.toCharArray();

    }
    */
}
