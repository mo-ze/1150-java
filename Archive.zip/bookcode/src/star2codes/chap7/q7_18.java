package star2codes.chap7;

public class q7_18 {
//    (Bubble sort) Write a sort method that uses the bubble-sort algorithm.
/*
@code already in my arrays
 */
    public static void main(String[] args) {
        System.out.println("unsorted");
        myarrays.displayarr(myarrays.quickarr());
    System.out.println("sorted");
    myarrays.displayarr(  myarrays.bubblesort(myarrays.quickarr()));
    }
}
