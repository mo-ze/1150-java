null
//
package srcRootDirectory.chap1;
package rting/srcRootDirectory.chap1;
package ootDirectory.chap1;
null
//
//

public class q {
    public static void main(String[] args) {

    }
}
