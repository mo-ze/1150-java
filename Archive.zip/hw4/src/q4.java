
public class q4 {

    public static void main(String[] args) {
        int randomnum=(int)(Math.random()*25)+97;
        char c=(char) randomnum;
        System.out.println("random lowercase letter: "+c);


    }

}
