the professor said that we can use as many method as we want



  2019-07-18  java send me upgrade last night and i installed it.
  i dont know if you have upgraded the version or if you are using an old version.
   here is my configuration: (copied directly from the terminal )

    java version "1.8.0_211"
    Java(TM) SE Runtime Environment (build 1.8.0_211-b12)
    Java HotSpot(TM) 64-Bit Server VM (build 25.211-b12, mixed mode)
