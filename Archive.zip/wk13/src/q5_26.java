//this is question3


public class q5_26 {
    public static void main(String[] args) {
      System.out.println(factorial(5));
    }
    public static int factorial(int x){
//            while(x<=1) {
        int fact = 1;
        for (int i = x; i <=1 ; i--) {

        fact=x*i;

            }

        return fact ;




}
}
